Basic UI for 29 card game.
